<?php
session_start();
if ($_SESSION['user']){
    header('Location: index.php');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Регистрейшон</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<form action="vendor/signup.php" method="post" enctype="multipart/form-data">
    <label>ФИО</label>
    <input type="text" name="full_name">
    <label>Логин</label>
    <input type="text" name="login">
    <label>Email</label>
    <input type="text" name="email">
    <label>Изображение пользователя</label>
    <input type="file" name="avatar">
    <label>Пароль</label>
    <input type="password" name="password">
    <label>Подтверждение пароля</label>
    <input type="password" name="password_confirm">
    <button>Зарегистрироваться</button>
    <p>Есть аккаунт? Авторизируйтесь <a href="index.php">Здесь</a></p>
        <?php
        if(isset($_SESSION['message'])) {
            echo ' <p class="msg"> ' . $_SESSION['message'] . ' </p> ';
        }
        unset($_SESSION['message']);

        ?>
</form>
</body>
</html>