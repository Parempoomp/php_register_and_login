<?php
session_start();
if (isset($_SESSION['user'])){
    header('Location: logo.php');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизейшон</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <form method="post" action="vendor/signin.php">
        <label>Логин</label>
        <input type="text" name="login">
        <label>Пароль</label>
        <input type="password" name="password">
        <button>Войти</button>
        <p>У вас нет аккаунта - Зарегистрируйтесь по фишинговой <a href="register.php">Ссылке</a> прямо здесь и сейчас!</p>
        <?php
        if(isset($_SESSION['message'])) {
            echo ' <p class="msg"> ' . $_SESSION['message'] . ' </p> ';
        }
        unset($_SESSION['message']);
        ?>
    </form>
</body>
</html>